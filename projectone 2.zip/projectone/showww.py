#from matminer.datasets import get_available_datasets as g_a_d 
#print(g_a_d()) #show the available dataset
from matminer.datasets import load_dataset
import copy
import numpy as np
import getdata
datalocation="/Users/fengrui/pythondata"
df = load_dataset('wolverton_oxides',data_home=datalocation)#choose data set"dielectric_constant"to load
#print(df.head())

reca=dict()
num=0
for i in df['atom a']:
  if i in reca.keys():
    continue
  else:
    reca[i]=num
    num+=1
#print(reca)

recb=dict()
num=0
for i in df['atom b']:
  if i in recb.keys():
    continue
  else:
    recb[i]=num
    num+=1
#print(recb)

recld=dict()
num=0
for i in df['lowest distortion']:
  if i in recld.keys():
    continue
  else:
    recld[i]=num
    num+=1
print(recld)


df['atom a']=df['atom a'].map(reca)
df['atom b']=df['atom b'].map(recb)
df['lowest distortion']=df['lowest distortion'].map(recld)

df.drop(columns=['formula'])

y=copy.deepcopy(df['gap pbe'])

x=copy.deepcopy(df.drop(columns=['gap pbe','formula']))

xtr=np.array(x[0:4001])
xva=np.array(x[4001:4801])
xte=np.array(x[4801:-1])
ytr=np.array(x[0:4001])
yva=np.array(x[4001:4801])
yte=np.array(x[4801:-1])
load_data_wrapper(xtr,ytr,xva,yva,xte,yte)
import train
a=train.trainn(10,10,3,14,1,1)


#print(df)
#excel_path=datalocation
#df.to_excel('df.xlsx')
