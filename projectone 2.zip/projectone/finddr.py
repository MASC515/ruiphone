import sys
import os
def mnt_mod(modn):
    pwd=list(os.popen("pwd").read())
    tmp=list()
    for i in pwd:
        if i ==' ':
            tmp.append('\\')
        tmp.append(i)
    pwd=''.join(tmp)
    mdr=os.popen(("find "+pwd[:-1]+" -name "+modn)).read()
    '''for j in range(0,len(mdr)):
        if mdr[j]==' ':
            mdr=str(list(mdr).insert(j,'\\'))'''
    realdr=mdr[:-(len(modn)+2)]
    filedr=mdr[:-1]
    sys.path.append(realdr)
    return (realdr,filedr)
