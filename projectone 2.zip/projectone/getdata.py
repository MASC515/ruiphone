def load_data_wrapper(xtr,ytr,xva,yva,xte,yte):
    training_inputs = [np.reshape(x1, (14, 1)) for x1 in xtr]
    training_results = [vectorized_result(y1) for y1 in ytr]
    training_data = list(zip(training_inputs, training_results))
    validation_inputs = [np.reshape(x2, (14, 1)) for x2 in xva]
    validation_results = [vectorized_result(y2) for y2 in yva]
    validation_data = list(zip(validation_inputs, validation_results))
    test_inputs = [np.reshape(x3, (14, 1)) for x3 in xte]
    test_results = [vectorized_result(y3) for y3 in yte]
    test_data = list(zip(test_inputs, test_results))
    return (training_data, validation_data, test_data)
    