import finddr
finddr.mnt_mod("network.py")
import network
import getdata
class trainn:
    def __init__(self,epo:int,mini_batch_s,etaa,*args):
        training_data, validation_data, test_data = getdata.load_data_wrapper(xtr,ytr,xva,yva,xte,yte)
        self.net = network.Network(args)
        self.net.SGD(training_data,epo,mini_batch_s,etaa, test_data=test_data)
